package com.example.app_finanas_af;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentReference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FirebaseHelper {

    public static void salvarLembrete(Reminder r, Runnable callback) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String, Object> dados = new HashMap<>();
        dados.put("titulo", r.titulo);
        dados.put("descricao", r.descricao);
        dados.put("dataHora", r.dataHora);
        dados.put("usuarioId", r.usuarioId);
        dados.put("concluido", r.concluido);
        dados.put("anotacoes", r.anotacoes);
        dados.put("categoria", r.categoria);
        dados.put("corHex", r.corHex);

        List<Map<String, Object>> subitensMap = r.subitens.stream().map(s -> {
            Map<String, Object> m = new HashMap<>();
            m.put("nome", s.nome);
            m.put("feito", s.feito);
            return m;
        }).collect(Collectors.toList());
        dados.put("subitens", subitensMap);


        if (r.id != null && !r.id.isEmpty()) {
            db.collection("lembretes")
                    .document(r.id)
                    .set(dados)
                    .addOnSuccessListener(aVoid -> callback.run());
        } else {
            db.collection("lembretes")
                    .add(dados)
                    .addOnSuccessListener(doc -> {
                        r.id = doc.getId();
                        callback.run();
                    });
        }
    }
}
