package com.example.app_finanas_af;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.*;

public class DetalheLembreteActivity extends AppCompatActivity {

    private EditText edtTitulo, edtDescricao, edtAnotacoes, edtNovaSubtarefa;
    private CheckBox chkConcluido;
    private RecyclerView recyclerSubitens;
    private Button btnAdicionarSubtarefa, btnSalvar, btnExcluir;
    private SubitemAdapter subitemAdapter;
    private Reminder lembrete;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhe_lembrete);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtDescricao = findViewById(R.id.edtDescricao);
        edtAnotacoes = findViewById(R.id.edtAnotacoes);
        edtNovaSubtarefa = findViewById(R.id.edtNovaSubtarefa);
        chkConcluido = findViewById(R.id.chkConcluido);
        recyclerSubitens = findViewById(R.id.recyclerSubtarefas);
        btnAdicionarSubtarefa = findViewById(R.id.btnAdicionarSubtarefa);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnExcluir = findViewById(R.id.btnExcluir);

        String lembreteId = getIntent().getStringExtra("lembreteId");

        if (lembreteId == null || lembreteId.isEmpty()) {
            Toast.makeText(this, "Erro ao carregar lembrete.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        FirebaseFirestore.getInstance()
                .collection("lembretes")
                .document(lembreteId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    lembrete = documentSnapshot.toObject(Reminder.class);
                    if (lembrete == null) {
                        Toast.makeText(this, "Lembrete não encontrado.", Toast.LENGTH_SHORT).show();
                        finish();
                        return;
                    }

                    lembrete.id = documentSnapshot.getId();

                    edtTitulo.setText(lembrete.titulo);
                    edtDescricao.setText(lembrete.descricao);
                    edtAnotacoes.setText("");
                    chkConcluido.setChecked(lembrete.concluido);

                    if (lembrete.subitens == null) lembrete.subitens = new ArrayList<>();

                    subitemAdapter = new SubitemAdapter(lembrete.subitens);
                    recyclerSubitens.setLayoutManager(new LinearLayoutManager(this));
                    recyclerSubitens.setAdapter(subitemAdapter);

                    btnAdicionarSubtarefa.setOnClickListener(v -> {
                        String nome = edtNovaSubtarefa.getText().toString().trim();
                        if (!nome.isEmpty()) {
                            lembrete.subitens.add(new Subitem(nome, false));
                            subitemAdapter.notifyDataSetChanged();
                            edtNovaSubtarefa.setText("");
                        }
                    });

                    btnSalvar.setOnClickListener(v -> salvarAlteracoes());
                    btnExcluir.setOnClickListener(v -> confirmarExclusao());
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Erro ao buscar lembrete.", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void salvarAlteracoes() {
        if (lembrete == null) return;

        String titulo = edtTitulo.getText().toString().trim();
        String descricao = edtDescricao.getText().toString().trim();

        if (titulo.isEmpty()) {
            Toast.makeText(this, "O título não pode estar vazio.", Toast.LENGTH_SHORT).show();
            return;
        }

        lembrete.titulo = titulo;
        lembrete.descricao = descricao;
        lembrete.concluido = chkConcluido.isChecked();

        if (lembrete.subitens == null) lembrete.subitens = new ArrayList<>();
        lembrete.subitens.removeIf(sub -> sub == null || sub.nome == null || sub.nome.trim().isEmpty());

        FirebaseFirestore.getInstance()
                .collection("lembretes")
                .document(lembrete.id)
                .set(lembrete)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Lembrete atualizado!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Erro ao salvar: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void confirmarExclusao() {
        new AlertDialog.Builder(this)
                .setTitle("Excluir lembrete")
                .setMessage("Tem certeza que deseja excluir este lembrete?")
                .setPositiveButton("Sim", (dialog, which) -> excluirLembrete())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void excluirLembrete() {
        FirebaseFirestore.getInstance()
                .collection("lembretes")
                .document(lembrete.id)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Lembrete excluído com sucesso!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Erro ao excluir: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
