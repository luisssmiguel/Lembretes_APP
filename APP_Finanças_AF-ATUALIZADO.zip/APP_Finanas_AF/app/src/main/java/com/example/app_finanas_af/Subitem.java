package com.example.app_finanas_af;

public class Subitem {
    public String nome;
    public boolean feito;

    public Subitem() {}

    public Subitem(String nome, boolean feito) {
        this.nome = nome;
        this.feito = feito;
    }
}