package com.example.app_finanas_af;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.*;

public class AddReminderActivity extends AppCompatActivity {

    private EditText edtTitulo, edtDescricao, edtNovoSubitem;
    private TextView txtDataSelecionada, txtHoraSelecionada;
    private Button btnSelecionarData, btnSelecionarHora, btnAdicionarSubitem, btnSalvar;
    private RecyclerView recyclerSubitens;
    private SubitemAdapter subitemAdapter;
    private List<Subitem> subitemList = new ArrayList<>();

    private Calendar calendarioSelecionado = Calendar.getInstance();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reminder);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtDescricao = findViewById(R.id.edtDescricao);
        edtNovoSubitem = findViewById(R.id.edtNovoSubitem);
        txtDataSelecionada = findViewById(R.id.txtDataSelecionada);
        txtHoraSelecionada = findViewById(R.id.txtHoraSelecionada);
        btnSelecionarData = findViewById(R.id.btnSelecionarData);
        btnSelecionarHora = findViewById(R.id.btnSelecionarHora);
        btnAdicionarSubitem = findViewById(R.id.btnAdicionarSubitem);
        btnSalvar = findViewById(R.id.btnSalvar);
        recyclerSubitens = findViewById(R.id.recyclerSubitens);

        subitemAdapter = new SubitemAdapter(subitemList);
        recyclerSubitens.setLayoutManager(new LinearLayoutManager(this));
        recyclerSubitens.setAdapter(subitemAdapter);

        btnSelecionarData.setOnClickListener(v -> {
            Calendar hoje = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                calendarioSelecionado.set(Calendar.YEAR, year);
                calendarioSelecionado.set(Calendar.MONTH, month);
                calendarioSelecionado.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                txtDataSelecionada.setText(sdf.format(calendarioSelecionado.getTime()));
            }, hoje.get(Calendar.YEAR), hoje.get(Calendar.MONTH), hoje.get(Calendar.DAY_OF_MONTH)).show();
        });

        btnSelecionarHora.setOnClickListener(v -> {
            Calendar agora = Calendar.getInstance();
            new TimePickerDialog(this, (view, hourOfDay, minute) -> {
                calendarioSelecionado.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendarioSelecionado.set(Calendar.MINUTE, minute);
                calendarioSelecionado.set(Calendar.SECOND, 0);
                SimpleDateFormat sdfHora = new SimpleDateFormat("HH:mm", Locale.getDefault());
                txtHoraSelecionada.setText(sdfHora.format(calendarioSelecionado.getTime()));
            }, agora.get(Calendar.HOUR_OF_DAY), agora.get(Calendar.MINUTE), true).show();
        });

        btnAdicionarSubitem.setOnClickListener(v -> {
            String nome = edtNovoSubitem.getText().toString().trim();
            if (!nome.isEmpty()) {
                subitemList.add(new Subitem(nome, false));
                subitemAdapter.notifyDataSetChanged();
                edtNovoSubitem.setText("");
            }
        });

        btnSalvar.setOnClickListener(v -> salvarLembrete());
    }

    private void salvarLembrete() {
        String titulo = edtTitulo.getText().toString().trim();
        String descricao = edtDescricao.getText().toString().trim();
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Date dataHora = calendarioSelecionado.getTime();

        if (titulo.isEmpty() || txtDataSelecionada.getText().toString().contains("não") || txtHoraSelecionada.getText().toString().contains("não")) {
            Toast.makeText(this, "Preencha título, data e horário", Toast.LENGTH_SHORT).show();
            return;
        }

        String id = UUID.randomUUID().toString();
        Reminder lembrete = new Reminder(
                id,
                titulo,
                descricao,
                dataHora,
                uid,
                subitemList,
                false,
                "",
                "Pessoal",
                "#FF9800"
        );

        FirebaseHelper.salvarLembrete(lembrete, () -> {
            agendarNotificacao(lembrete);
            Toast.makeText(this, "Lembrete salvo!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void agendarNotificacao(Reminder r) {
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.putExtra("titulo", r.titulo);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                new Random().nextInt(),
                intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, r.dataHora.getTime(), pendingIntent);
    }
}
