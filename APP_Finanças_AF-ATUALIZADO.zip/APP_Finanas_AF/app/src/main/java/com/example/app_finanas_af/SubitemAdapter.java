package com.example.app_finanas_af;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SubitemAdapter extends RecyclerView.Adapter<SubitemAdapter.ViewHolder> {

    private List<Subitem> lista;

    public SubitemAdapter(List<Subitem> lista) {
        this.lista = lista;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_subitem, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Subitem s = lista.get(position);
        holder.checkBox.setText(s.nome);
        holder.checkBox.setChecked(s.feito);
        holder.checkBox.setOnCheckedChangeListener((btn, isChecked) -> s.feito = isChecked);
    }

    @Override
    public int getItemCount() {
        return lista != null ? lista.size() : 0;
    }


    public void setSubitens(List<Subitem> novaLista) {
        this.lista = novaLista;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.checkboxSubitem);
        }
    }
}
