package com.example.app_finanas_af;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ReminderAdapter adapter;
    private List<Reminder> reminderList = new ArrayList<>();
    private Button btnAdicionar, btnLogout;

    private LinearLayout btnMeuDia, btn7Dias, btnTodasTarefas, btnCalendario;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerReminders);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        btnLogout = findViewById(R.id.btnLogout);

        btnMeuDia = findViewById(R.id.btnMeuDia);
        btn7Dias = findViewById(R.id.btn7Dias);
        btnTodasTarefas = findViewById(R.id.btnTodasTarefas);
        btnCalendario = findViewById(R.id.btnCalendario);

        adapter = new ReminderAdapter(reminderList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnAdicionar.setOnClickListener(v -> startActivity(new Intent(this, AddReminderActivity.class)));

        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        btnMeuDia.setOnClickListener(v -> filtrarPorHoje());
        btn7Dias.setOnClickListener(v -> filtrar7Dias());
        btnTodasTarefas.setOnClickListener(v -> carregarLembretes());
        btnCalendario.setOnClickListener(v -> startActivity(new Intent(this, CalendarioActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        carregarLembretes();
    }

    private void carregarLembretes() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseFirestore.getInstance()
                .collection("lembretes")
                .whereEqualTo("usuarioId", uid)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    reminderList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Reminder r = doc.toObject(Reminder.class);
                        r.id = doc.getId();
                        reminderList.add(r);
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private void filtrarPorHoje() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        Date inicio = cal.getTime();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date fim = cal.getTime();

        FirebaseFirestore.getInstance()
                .collection("lembretes")
                .whereEqualTo("usuarioId", uid)
                .whereGreaterThanOrEqualTo("dataHora", inicio)
                .whereLessThan("dataHora", fim)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    reminderList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Reminder r = doc.toObject(Reminder.class);
                        r.id = doc.getId();
                        reminderList.add(r);
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private void filtrar7Dias() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Calendar cal = Calendar.getInstance();
        Date hoje = cal.getTime();
        cal.add(Calendar.DAY_OF_MONTH, 7);
        Date daqui7Dias = cal.getTime();

        FirebaseFirestore.getInstance()
                .collection("lembretes")
                .whereEqualTo("usuarioId", uid)
                .whereGreaterThanOrEqualTo("dataHora", hoje)
                .whereLessThan("dataHora", daqui7Dias)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    reminderList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Reminder r = doc.toObject(Reminder.class);
                        r.id = doc.getId();
                        reminderList.add(r);
                    }
                    adapter.notifyDataSetChanged();
                });
    }
}