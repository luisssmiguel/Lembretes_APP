package com.example.app_finanas_af;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Reminder implements Serializable {
    public String id;
    public String titulo;
    public String descricao;
    public Date dataHora;
    public String usuarioId;
    public List<Subitem> subitens;
    public boolean concluido;
    public String anotacoes;
    public String categoria;
    public String corHex;

    public Reminder() {}


    public Reminder(String id, String titulo, String descricao, Date dataHora, String usuarioId,
                    List<Subitem> subitens, boolean concluido, String anotacoes, String categoria, String corHex) {
        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataHora = dataHora;
        this.usuarioId = usuarioId;
        this.subitens = subitens;
        this.concluido = concluido;
        this.anotacoes = anotacoes;
        this.categoria = categoria;
        this.corHex = corHex;
    }
}
