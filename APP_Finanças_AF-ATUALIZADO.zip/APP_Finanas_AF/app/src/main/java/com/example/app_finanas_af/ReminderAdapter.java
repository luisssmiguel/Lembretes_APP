package com.example.app_finanas_af;

import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ViewHolder> {

    private final List<Reminder> lista;
    private final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());

    public ReminderAdapter(List<Reminder> lista) {
        this.lista = lista;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reminder, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Reminder r = lista.get(position);

        holder.txtTitulo.setText(r.titulo);
        holder.txtDescricao.setText(r.descricao);
        holder.txtData.setText(sdf.format(r.dataHora));
        holder.chkFeito.setOnCheckedChangeListener(null); // evita bug ao reciclar
        holder.chkFeito.setChecked(r.concluido);

        if (r.corHex != null && !r.corHex.isEmpty()) {
            try {
                holder.viewCategoria.setBackgroundColor(Color.parseColor(r.corHex));
            } catch (IllegalArgumentException ignored) {
                holder.viewCategoria.setBackgroundColor(Color.GRAY);
            }
        } else {
            holder.viewCategoria.setBackgroundColor(Color.GRAY);
        }

        holder.chkFeito.setOnCheckedChangeListener((buttonView, isChecked) -> {
            r.concluido = isChecked;
            if (r.id != null && !r.id.isEmpty()) {
                FirebaseFirestore.getInstance()
                        .collection("lembretes")
                        .document(r.id)
                        .update("concluido", isChecked);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (r.id != null && !r.id.isEmpty()) {
                Intent intent = new Intent(v.getContext(), DetalheLembreteActivity.class);
                intent.putExtra("lembreteId", r.id);
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtTitulo, txtDescricao, txtData;
        CheckBox chkFeito;
        View viewCategoria;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitulo = itemView.findViewById(R.id.txtTitulo);
            txtDescricao = itemView.findViewById(R.id.txtDescricao);
            txtData = itemView.findViewById(R.id.txtData);
            chkFeito = itemView.findViewById(R.id.chkFeito);
            viewCategoria = itemView.findViewById(R.id.viewCategoria);
        }
    }
}
