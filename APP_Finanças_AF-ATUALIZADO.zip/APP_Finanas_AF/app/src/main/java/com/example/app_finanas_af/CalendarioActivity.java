package com.example.app_finanas_af;

import android.os.Bundle;
import android.widget.CalendarView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.text.SimpleDateFormat;
import java.util.*;

public class CalendarioActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private RecyclerView recyclerView;
    private ReminderAdapter adapter;
    private List<Reminder> lista = new ArrayList<>();
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);

        calendarView = findViewById(R.id.calendarView);
        recyclerView = findViewById(R.id.recyclerLembretesDia);

        adapter = new ReminderAdapter(lista);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        Date hoje = new Date();
        buscarLembretesDoDia(hoje);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar cal = Calendar.getInstance();
            cal.set(year, month, dayOfMonth, 0, 0, 0);
            buscarLembretesDoDia(cal.getTime());
        });
    }

    private void buscarLembretesDoDia(Date dataSelecionada) {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        Calendar calInicio = Calendar.getInstance();
        calInicio.setTime(dataSelecionada);
        calInicio.set(Calendar.HOUR_OF_DAY, 0);
        calInicio.set(Calendar.MINUTE, 0);
        calInicio.set(Calendar.SECOND, 0);
        Date inicio = calInicio.getTime();

        Calendar calFim = (Calendar) calInicio.clone();
        calFim.add(Calendar.DAY_OF_MONTH, 1);
        Date fim = calFim.getTime();

        FirebaseFirestore.getInstance()
                .collection("lembretes")
                .whereEqualTo("usuarioId", uid)
                .whereGreaterThanOrEqualTo("dataHora", inicio)
                .whereLessThan("dataHora", fim)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    lista.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        lista.add(doc.toObject(Reminder.class));
                    }
                    adapter.notifyDataSetChanged();
                });
    }
}
